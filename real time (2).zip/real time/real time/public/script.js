const socket = io();

// Auth Logic
const setupAuth = (formId, url) => {
    const form = document.getElementById(formId);
    if (!form) return;
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {};
        new FormData(form).forEach((v, k) => formData[k] = v);
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });
        const data = await res.json();
        if (res.ok) {
            if (data.userName) localStorage.setItem('user', data.userName);
            window.location.href = url === '/login' ? 'dashboard.html' : 'login.html';
        } else alert(data.message);
    });
};
setupAuth('registerForm', '/register');
setupAuth('loginForm', '/login');

// Dashboard Logic
if (window.location.pathname.includes('dashboard')) {
    const user = localStorage.getItem('user') || 'Developer';
    if (document.getElementById('user-display')) document.getElementById('user-display').innerText = user;

    document.getElementById('logout-btn').onclick = () => {
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    };

    document.getElementById('new-event-btn').onclick = () => socket.emit('new-event', { user });

    const chatInput = document.getElementById('chat-input');
    document.getElementById('send-btn').onclick = () => {
        if (chatInput.value.trim()) {
            socket.emit('send-chat', { user, text: chatInput.value });
            chatInput.value = '';
        }
    };

    socket.on('receive-chat', data => {
        const div = document.createElement('div');
        div.innerHTML = `<strong>${data.user}:</strong> ${data.text}`;
        document.getElementById('chat-window').appendChild(div);
    });

    socket.on('user-count-update', count => document.getElementById('live-count').innerText = count);
    socket.on('activity-log', data => {
        const div = document.createElement('div');
        div.innerHTML = `<strong>${data.user}</strong> ${data.msg}`;
        document.getElementById('activity-feed').prepend(div);
    });
}1