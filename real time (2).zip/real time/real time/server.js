const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MySQL Connection Link
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'aishwarya', // Your MySQL password
    database: 'eventsync_db'
});

db.connect(err => {
    if (err) console.error("❌ MySQL Link Failed: " + err.message);
    else console.log("✅ Database Linked Successfully");
});

// Registration Route
app.post('/register', async (req, res) => {
    const { fullName, email, password } = req.body;
    try {
        const hashedPw = await bcrypt.hash(password, 10);
        db.query("INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)", 
        [fullName, email, hashedPw], (err) => {
            if (err) return res.status(400).json({ message: "Email already exists" });
            res.status(200).json({ message: "Success" });
        });
    } catch (e) { res.status(500).json({ message: "Server Error" }); }
});

// Login Route
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
        if (err || results.length === 0) return res.status(401).json({ message: "User not found" });
        const match = await bcrypt.compare(password, results[0].password);
        if (!match) return res.status(401).json({ message: "Invalid credentials" });
        res.status(200).json({ userName: results[0].full_name });
    });
});

// Real-Time Logic
io.on('connection', (socket) => {
    io.emit('user-count-update', io.engine.clientsCount);
    socket.on('send-chat', (data) => io.emit('receive-chat', data));
    socket.on('new-event', (data) => io.emit('activity-log', { user: data.user, msg: "initiated a real-time sync" }));
    socket.on('disconnect', () => io.emit('user-count-update', io.engine.clientsCount));
});

server.listen(PORT, () => {
    console.log(`🚀 EventSync Server: http://localhost:${PORT}`);
});